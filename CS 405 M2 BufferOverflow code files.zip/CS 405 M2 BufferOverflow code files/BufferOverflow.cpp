// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <cstring>  // For safe string handling

int main()
{
    std::cout << "Buffer Overflow Example" << std::endl;

    // Account number declared before the input buffer
    const std::string account_number = "CharlieBrown42";

    // Fixed buffer size for user input
    char user_input[20] = { 0 };  // Initialize with null characters

    std::cout << "Enter a value (Max 19 characters): ";

    // Using std::cin.get() to safely limit input size
    std::cin.get(user_input, 20);

    // Check if the user entered too many characters
    if (std::cin.peek() != '\n') {
        std::cin.ignore(10000, '\n');  // Clear excessive input
        std::cout << "Warning: Input exceeded limit and has been truncated to 19 characters.\n";
    }

    std::cout << "You entered: " << user_input << std::endl;
    std::cout << "Account Number = " << account_number << std::endl;

    return 0;
}
